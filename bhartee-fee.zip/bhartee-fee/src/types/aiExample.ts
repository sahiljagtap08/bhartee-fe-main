export type AiExample = {
  id: number;
  icon: string;
  title: string;
  description: string;
  rotate?: boolean;
  path: string;
};
