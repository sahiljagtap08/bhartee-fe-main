export type Review = {
  id: number;
  userName: string;
  userDesignation: string;
  userImage: string;
  description: string;
};
