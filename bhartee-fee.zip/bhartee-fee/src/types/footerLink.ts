export type FooterLink = {
  id: number;
  title: string;
  href: string;
  newTab?: boolean;
};
